#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Разработчик: apkawa@gmail.com
Сайт проекта: http://code.google.com/p/uimge/
'''
import optparse
from sys import argv,exit,stderr,stdout
from os import stat
from re import sub,search
from libuimge import imagehost,lang

VERSION = '0.05.6.9'
opt_help,error_mes,messages=lang.check()

# Парсинг опций, и вывод хелпа.
def parseopt(arg):
    usage = opt_help['usage']
    version = 'uimgepy-'+VERSION
    parser = optparse.OptionParser(usage=usage, version=version)
    # Major options
    group_1 = optparse.OptionGroup(parser, opt_help['Major options'])
    group_1.add_option('-i','--ipicture',action='store_const', const='i', dest='check', \
                       help=opt_help['--ipicture'])
    group_1.add_option('-r','--radikal',action='store_const', const='r', dest='check', \
                       help=opt_help['--radikal'])
    group_1.add_option('-s','--imageshack',action='store_const', const='s', dest='check', \
                       help=opt_help['--imageshack'])
    group_1.add_option('-t','--tinypic',action='store_const', const='t', dest='check',\
                       help=opt_help['--tinypic'])
    group_1.add_option('-m','--smages',action='store_const', const='m', dest='check',\
                       help=opt_help['--smages'])
    parser.add_option_group(group_1)
    # Additional options
    group_2 = optparse.OptionGroup(parser, opt_help['Additional options'])
    group_2.add_option('-n','--name', action='store', default=None, dest='name', \
                       help=opt_help['--name'])
    group_2.add_option('-f','--file', action='store', default=None, dest='filelist', \
                       help=opt_help['--file'])
    #Testing
    #group_2.add_option('--url','--url-mode',action='store_true', dest='mode', \
    #                   help=opt_help['--url-mode'])    
    parser.add_option_group(group_2)
    group_3 = optparse.OptionGroup(parser, opt_help['Output options'])
    group_3.add_option('--ba','--bb-all',action='store_true', dest='out_ba', \
                       help=opt_help['--bb-all'])
    group_3.add_option('--bt','--bb-thumb',action='store_true', dest='out_bt', \
                       help=opt_help['--bb-thumb'])
    group_3.add_option('--bo','--bb-orig',action='store_true', dest='out_bo', \
                       help=opt_help['--bb-orig'])
    group_3.add_option('--du','--direct-url',action='store_true', dest='out_url', \
                       help=opt_help['--direct-url'])
    group_3.add_option('--usr','--user-output',action='store',default=None, dest='out_usr', \
                       help=opt_help['--user-output'])    
    parser.add_option_group(group_3)
#Этот режим работает только для radikal.ru и ipicture.ru
    
    
    #parser.add_option_group(group_2)
    opt, arguments = parser.parse_args(args=arg,)

    if opt.check == None:
        print error_mes['Enter option']
        parser.print_help()
        exit()
    return opt, arguments

# Вывод урлов
def outprint(urls, out_ba, out_bt, out_bo, out_url, out_usr):
    if out_url or (out_ba==None and out_bo==None and out_bt==None and out_usr == None):
        for url in urls:
            stdout.write('%s\n'%url[0])
    if out_ba:
        out_bt = True 
        out_bo = True
    if out_bt:
        stdout.write('\n')
        for url in urls:
            stdout.write('[URL=%s][IMG]%s[/IMG][/URL] ' %(url[0], url[1]))
        stdout.write('\n')
    if out_bo:
        stdout.write('\n')
        for url in urls:
            stdout.write('[IMG]%s[/IMG]\n' %(url[0]))
    if out_usr:
        stdout.write('\n')
        for url in urls: 
            stdout.write(sub('\\\\n','\n',sub('#TMB#',url[1],sub('#URL#',url[0],out_usr))))
        stdout.write('\n')


def main(arg):
    
    opt, filenames = parseopt(arg)    
    #Чтение файллиста
    if opt.filelist:
        filenames = []
        f = open(opt.filelist,'r')
        files = f.readlines()
        f.close()
        for file in files: filenames.append(sub('\n','',file))
    urls = []
    progress = len(filenames)
    i=0
    host=opt.check
    #Проверка модуля.
    if opt.name:
        try:
            from PIL import Image
        except ImportError:
            stderr.write(error_mes['ImportError PIL'])
            opt.name = None
    for filename in filenames:
        if not search('(\.jpeg$)|(\.jpg$)|(\.png$)|(\.gif$)|(\.bmp$)',filename):
            stderr.write(error_mes['file format'])
            progress -= 1
            continue
        
        if search('^http\:\/\/',filename): 
            mode=True
            opt.name = None
        else: mode = False
        
        if not mode: 
            
            try:
                test=stat(filename)
            except OSError:
                stderr.write('Not file\n')
                progress -= 1 
                continue
        
        if progress >= 2:
            i += 1
            stderr.write(messages['progress']%(i,progress) )
        send=[filename,opt.name,mode]
        
        if host == 'i': 
            url=imagehost.ipicture(send)
        elif host == 'r': 
            url=imagehost.radikal(send)
        elif host == 'f': 
            url=imagehost.funkyimg(send)
        elif host == 's': 
            url=imagehost.imageshack(send)
        elif host == 't': 
            url=imagehost.tinypic(send)
        elif host == 'm': 
            url=imagehost.smages(send)
        
        if url: 
            urls.append((url[0],url[1]))
        else: 
            continue
        
    outprint(urls,opt.out_ba,opt.out_bt,opt.out_bo,opt.out_url,opt.out_usr)

main(argv[1:])



