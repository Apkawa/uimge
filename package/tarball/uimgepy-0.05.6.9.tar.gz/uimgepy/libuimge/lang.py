# -*- coding: utf-8 -*-
from locale import getdefaultlocale

def ru_RU():
    options_help = {'usage':u'Использование: python %prog [-i|-r|-f|-s|-t] картинка',\
                    'Major options':u'Основные опции',\
                    '--ipicture':u'Залить на ipicture.ru',\
                    '--radikal':u'Залить на radikal.ru',\
                    '--imageshack':u'Залить на imageshack.us',\
                    '--tinypic':u'Залить на tinypic.com',\
                    '--smages':u'Залить на smages.com',\
                    'Additional options':u'Дополнительные опции',\
                    '--name':u'Добавить свое имя в превью картинки (Требуется PIL)',\
                    '--file':u'Взять список файлов или url из текстового файла.',\
                    '--url-mode':u'Режим перезаливки картинок с других источников в сети.',\
                    'Output options':u'Опции вывода',\
                    '--bb-all':u'Объединяет опции -bo и -bt',\
                    '--bb-thumb':u'Вывести в ввиде BB-кода с превью',\
                    '--bb-orig':u'Вывести в ввиде BB-кода в оригинальном размере',\
                    '--direct-url':u'Прямая ссылка на картинку',\
                    '--user-output':u'Установить свой вид вывода. \n#URL# - url к картинке оригинального размера, \n#TMB# - url к превью. \nПример: [URL=#URL#][IMG]#TMB#[/IMG][/URL]',\
                }
    error_mesages = {'Enter option':'Нет основных опций! Введите [-i|-r|-f|-s|-t]...',\
                     'ImportError PIL':'Ошибка: Нет модуля Python Imaging Library (PIL)!\nПожалуйста установите его.\n',\
                     'Not support hosting':'Данная операция не позволяется этим хостингом\n',\
                     'file format':'This file not image format\n',\
                 }
    messages={'progress':'Залито %d картинок из %d.\r'}
    return options_help,error_mesages,messages

def en_EN():
    options_help = {'usage':'usage: python %prog [-i|-r|-f|-s|-t] picture',\
                    'Major options':'Major options',\
                    '--ipicture':'Upload to ipicture.ru',\
                    '--radikal':'Upload to  radikal.ru',\
                    '--imageshack':'Upload to  imageshack.us',\
                    '--tinypic':'Upload to  tinypic.com',\
                    '--smages':'Upload to  smages.com',\
                    'Additional options':'Additional options',\
                    '--name':'Adding a name to preview images (Used PIL). Works with [-r|-i]',\
                    '--file':'Upload image from list',\
                    '--url-mode':'Upload by url. Work with [-r|-i]',\
                    'Output options':'Output options',\
                    '--bb-all':'List all the options bb code',\
                    '--bb-thumb':'Output in bb code with a preview',\
                    '--bb-orig':'Output in bb code in the original amount',\
                    '--direct-url':'The withdrawal of direct references to pictures',\
                    '--user-output':'Set user output #URL# - original image, #TMB# - preview image   Sample: [URL=#URL#][IMG]#TMB#[/IMG][/URL]',\
                }
    error_mesages = {'Enter option':'Enter option [-i|-r|-f|-s|-t]...',\
                     'ImportError PIL':'Error: No module Python Imaging Library (PIL)!\nPlease install it.\n',\
                     'Not support hosting':'This operation does not allow it hosted.\n',\
                     'file format':'This file not image format\n',\
                 }
    messages={'progress':'Upload %d images of %d.\r'}
    return options_help,error_mesages,messages

def check(LANG=getdefaultlocale()[0]):
    if LANG == 'ru_RU':
        return ru_RU()
    else:
        return en_EN()
    
#check(getdefaultlocale()[0])


'''
--version             show program's version number and exit
  -h, --help            show this help message and exit

  Major options:
    -i, --ipicture      Upload to ipicture.ru
    -r, --radikal       Upload to radikal.ru
    -s, --imageshack    Upload to imageshack.us
    -t, --tinypic       Upload to tinypic.com
    -m, --smages        Upload to smages.com

  Additional options:
    -n NAME, --name=NAME
                        Adding a name to preview images (Used PIL). Works with
                        [-r|-i]
    -f FILELIST, --file=FILELIST
                        Upload image from list
    --url, --url-mode   Upload by url. Work with [-r|-i]

  Output options:
    --ba, --bb-all      List all the options bb code
    --bt, --bb-thumb    Output in bb code with a preview
    --bo, --bb-orig     Output in bb code in the original amount
    --du, --direct-url  The withdrawal of direct references to pictures
    --usr=OUT_USR, --user-output=OUT_USR
                        Set user output #URL# - original image, #TMB# -
                        preview image   Sample:
                        [URL=#URL#][IMG]#TMB#[/IMG][/URL]
                        
def parseopt(arg):
    lang.check()
    usage = "usage: python %prog [-i|-r|-f|-s|-t] picture"
    version = 'uimgepy-'+VERSION
    parser = optparse.OptionParser(usage=usage, version=version)
    # Major options
    group_1 = optparse.OptionGroup(parser, 'Major options')
    group_1.add_option('-i','--ipicture',action='store_const', const='i', dest='check', \
                       help='Upload to ipicture.ru')
    group_1.add_option('-r','--radikal',action='store_const', const='r', dest='check', \
                       help='Upload to radikal.ru')
    group_1.add_option('-s','--imageshack',action='store_const', const='s', dest='check', \
                       help='Upload to imageshack.us')
    group_1.add_option('-t','--tinypic',action='store_const', const='t', dest='check',\
                       help='Upload to tinypic.com')
    group_1.add_option('-m','--smages',action='store_const', const='m', dest='check',\
                       help='Upload to smages.com')

    #group_1.add_option('-f','--funkyimg',action='store_const', const='f', dest='check', help='Upload to funkyimg.com')
    parser.add_option_group(group_1)
    # Additional options
    group_2 = optparse.OptionGroup(parser, 'Additional options')
    group_2.add_option('-n','--name', action='store', default=None, dest='name', \
                       help='Adding a name to preview images (Used PIL). Works with [-r|-i]')
    group_2.add_option('-f','--file', action='store', default=None, dest='filelist', \
                       help='Upload image from list')
    #Testing
    group_2.add_option('--url','--url-mode',action='store_true', dest='mode', \
                       help='Upload by url. Work with [-r|-i]')    
    parser.add_option_group(group_2)
    group_3 = optparse.OptionGroup(parser, 'Output options')
    group_3.add_option('--ba','--bb-all',action='store_true', dest='out_ba', \
                       help='List all the options bb code')
    group_3.add_option('--bt','--bb-thumb',action='store_true', dest='out_bt', \
                       help='Output in bb code with a preview')
    group_3.add_option('--bo','--bb-orig',action='store_true', dest='out_bo', \
                       help='Output in bb code in the original amount')
    group_3.add_option('--du','--direct-url',action='store_true', dest='out_url', \
                       help='The withdrawal of direct references to pictures')
    group_3.add_option('--usr','--user-output',action='store',default=None, dest='out_usr', \
                       help='Set user output #URL# - original image, #TMB# - preview image \n Sample: [URL=#URL#][IMG]#TMB#[/IMG][/URL]')    
    parser.add_option_group(group_3)
#Этот режим работает только для radikal.ru и ipicture.ru
    
    
    #parser.add_option_group(group_2)
    opt, arguments = parser.parse_args(args=arg,)

    if opt.check == None:
        print 'Enter option [-i|-r|-f|-s|-t]...'
        parser.print_help()
        exit()
    return opt, arguments
'''