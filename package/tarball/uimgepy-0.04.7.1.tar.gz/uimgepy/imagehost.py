# -*- coding: utf-8 -*-
import libiu
from re import findall
from urllib import urlopen

def label(file, name):
    from PIL import Image
    from os import stat
    img=Image.open(file)
    size=stat(file).st_size/1024
    title='%s %sx%s %s Kb' %(name,str(img.size[0]),str(img.size[1]),str(size) )
    return title

def ipicture(send):
    file_name,label_name=send[0],send[1]
    ihost={\
           'host':'ipicture.ru', \
           'post':'/Upload/', \
           'name':'userfile'\
           }
    
    form_vaule = [\
              ('uploadtype','1'),\
              ('method','file'),\
              ('file','upload'),\
              ('thumb_resize_on','on'),('thumb_resize','200'),\
              ('submit','"Загрузить"')\
              ]
    if label_name != None:
        form_vaule.insert(-1,('string_small_on','on'))
        form_vaule.insert(-1,('string_small', label(file_name,label_name) ))
                          
    reurl=libiu.send_file(file_name, ihost, form_vaule)
    reurl=reurl.getheaders()[-5]
    reurl=findall('(http://.*.html)',reurl[1])
    url=findall('\[IMG\](http://.*)\[\/IMG\]',urlopen(reurl[0]).read())
    url=[url[0],url[2]]
    #return ihost,form_vaule
    return url

def radikal(send):
    file_name,label_name=send[0],send[1]
    ihost={\
       'host':'www.radikal.ru', \
       'post':'/action.aspx', \
       'name':'F'\
       }

    form_vaule = [\
              ('upload', 'yes'),\
              ('VM','200'),\
              ('CP','yes'),\
              ('Submit', '')\
              ]
    if label_name != None:
        form_vaule.insert(-1,('VE','yes'))
        form_vaule.insert(-1,('V', label(file_name,label_name) ))
        
    url=libiu.send_file(file_name, ihost, form_vaule)
    url=findall('\[IMG\](http://.*.radikal.ru.*)\[/IMG\]',url.read())
    return url
    

def funkyimg(send):
    file_name,label=send[0],send[1]
    ihost={\
           'host':'funkyimg.com', \
           'post':'/up.php', \
           'name':'file_0'\
           }
    form_vaule = [\
                  ('addInfo','on'),('addInfoType','label'),('labelText',label),\
                  ('upload','"Upload Images"'),('uptype','file'),\
                  ('file_1',''),('maxNumber','1'),('maxId','')
                  ]
    url=findall('\[IMG\](http://funkyimg.com/.*)\[/IMG\]\[/URL\]',\
                     libiu.send_file(file_name, ihost, form_vaule).read())
    url.reverse()
    return url



def imageshack(send):
    file_name,label=send[0],send[1]
    ihost={\
       'host':'imageshack.us', \
       'post':'/', \
       'name':'fileupload'\
       }

    form_vaule = [\
              ('uploadtype', 'on'),\
              ('Submit', '"host it!"')\
              ]
    #src=libiu.send_file(file_name, ihost, form_vaule).read()
    url=findall('value=\"(http://img.[\d]+?.imageshack.us/img[\d]+?/.*?/.*?)\"',\
                   libiu.send_file(file_name, ihost, form_vaule).read())
    tumburl=url[0].split('.')
    tumburl.insert(-1,'th')
    urls=[url[0],'.'.join(tumburl)]
    return urls

def tinypic(send):
    file_name,label=send[0],send[1]
    ihost={\
       'host':'s3.tinypic.com', \
       'post':'/upload.php', \
       'name':'the_file'\
       }

    form_vaule = [\
              ('action', 'upload'),\
              ('MAX_FILE_SIZE', '200000000'),\
              ('action', 'upload'),\
              ('Submit', '')\
              ]
    src=libiu.send_file(file_name, ihost, form_vaule).read()
    reurl=findall('http://tinypic.com/view.php\?pic=.*?\&s=[\d]',src)
    src=urlopen(reurl[0]).read()
    url=findall('\[IMG\](http://i[\d]+?.tinypic.com/.*?)\[/IMG\]',src)
    tumburl=url[0].split('.')
    tumburl[-2] += '_th'
    tumburl = '.'.join(tumburl)
    #print url, tumburl
    urls=[url[0],tumburl]
    return urls