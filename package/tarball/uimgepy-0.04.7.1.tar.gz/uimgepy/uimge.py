#!/usr/bin/python
# -*- coding: utf-8 -*-
import optparse
from sys import argv,exit,stderr,stdout


VERSION = '0.04.7.1'
'''
apkawa@gmail.com
Добавлены 2 хостинга, imageshack.us и tinypic.com. Проведен небольшой рефакторинг кода.

временно отключен funkyimg.com из за того что хостинг недоступен.

Добавлена возможность заливки картинок из заранее составленного листа
'''

def parseopt(arg):
    usage = "usage: python %prog [-i|-r|-f|-s|-t] picture"
    version = 'uimgepy-'+VERSION
    parser = optparse.OptionParser(usage=usage, version=version)
    # Major options
    group_1 = optparse.OptionGroup(parser, 'Major options')
    group_1.add_option('-i','--ipicture',action='store_const', const='i', dest='check', help='Upload to ipicture.ru')
    group_1.add_option('-r','--radikal',action='store_const', const='r', dest='check', help='Upload to radikal.ru')
    #group_1.add_option('-f','--funkyimg',action='store_const', const='f', dest='check', help='Upload to funkyimg.com')
    group_1.add_option('-s','--imageshack',action='store_const', const='s', dest='check', help='Upload to imageshack.us')
    group_1.add_option('-t','--tinypic',action='store_const', const='t', dest='check', help='Upload to tinypic.com')
    parser.add_option_group(group_1)
    # Additional options
    group_2 = optparse.OptionGroup(parser, 'Additional options')
    group_2.add_option('-n','--name', action='store', default=None, dest='name', help='Adding a name to preview images (Used PIL)')
    group_2.add_option('-f','--file', action='store', default=None, dest='filelist', help='Upload image from list')
    group_2.add_option('--ba','--bb-all',action='store_true', dest='out_ba', help='List all the options bb code')
    group_2.add_option('--bt','--bb-thumb',action='store_true', dest='out_bt', help='Output in bb code with a preview')
    group_2.add_option('--bo','--bb-orig',action='store_true', dest='out_bo', help='Output in bb code in the original amount')
    group_2.add_option('--url','--direct-url',action='store_true', dest='out_url', help='The withdrawal of direct references to pictures')
    group_2.add_option('-u','--user-output',action='store',default=None, dest='out_usr', help='Set user output \'#URL#\' - original image \'#TMB#\' - preview image \n Sample: [URL=#URL#][IMG]#TMB#[/IMG][/URL]')    
    parser.add_option_group(group_2)
    opt, arguments = parser.parse_args(args=arg,)

    if opt.check == None:
        print 'Enter option [-i|-r|-f|-s|-t]...'
        parser.print_help()
        exit()
    return opt, arguments

def outprint(urls, out_ba, out_bt, out_bo, out_url, out_usr):
    if out_url or (out_ba==None and out_bo==None and out_bt==None and out_usr == None): # - стало
        for url in urls:
            stdout.write('%s\n'%url[0])
    
    #if out_ba == True: 
    if out_ba:
        out_bt = True 
        out_bo = True
    if out_bt:
        stdout.write('\n')
        for url in urls:
            stdout.write('[URL=%s][IMG]%s[/IMG][/URL] ' %(url[0], url[1]))
        stdout.write('\n')
    if out_bo:
        stdout.write('\n')
        for url in urls:
            stdout.write('[IMG]%s[/IMG]\n' %(url[0]))
    if out_usr:
        stdout.write('\n')
        from re import sub 
        for url in urls: 
            stdout.write(sub('\\\\n','\n',sub('#TMB#',url[1],sub('#URL#',url[0],out_usr))))
        stdout.write('\n')


def main(arg):
    opt, filenames = parseopt(arg)
    
    import imagehost

    if opt.filelist:
        filenames = []
        f = open(opt.filelist,'r')
        files = f.readlines()
        f.close()
        from re import sub
        for file in files: filenames.append(sub('\n','',file))
    urls = []
    progress = len(filenames)
    i=0
    host=opt.check
    if opt.name != None:
        try:
            from PIL import Image
        except ImportError:
            stderr.write('Error: No module Python Imaging Library (PIL)!\nPlease install it.\n\n')
            opt.name = None
    for filename in filenames:
        if progress >= 2:
            i += 1
            stderr.write('Залито %d картинок из %d.\r'%(i,progress) )
            
        send=[filename,opt.name]
        if host == 'i': 
            url=imagehost.ipicture(send)
        if host == 'r': 
            url=imagehost.radikal(send)
        if host == 'f': 
            url=imagehost.funkyimg(send)
        if host == 's': 
            url=imagehost.imageshack(send)
        if host == 't': 
            url=imagehost.tinypic(send)
        urls.append((url[0],url[1]))
        
    outprint(urls,opt.out_ba,opt.out_bt,opt.out_bo,opt.out_url,opt.out_usr)


main(argv[1:])



