# -*- coding: utf-8 -*-
import os,optparse
from sys import argv,exit
#import re, urllib,libiu
import imagehost


def parseopt(arg):
    usage = "usage: %prog [options] picture."
    parser = optparse.OptionParser(usage=usage)
    parser.add_option('-i','--ipicture',action='store_const', const='i', dest='check', help='Upload to ipicture.ru')
    parser.add_option('-r','--radikal',action='store_const', const='r', dest='check', help='Upload to radikal.ru')
    parser.add_option('-f','--funkyimg',action='store_const', const='f', dest='check', help='Upload to funkyimg.com')
    parser.add_option('-s','--imageshack',action='store_const', const='s', dest='check', help='Upload to imageshack.us')
    parser.add_option('-t','--tinypic',action='store_const', const='t', dest='check', help='Upload to tinypic.com')
    parser.add_option('-n','--name', action='store', default=None, dest='name', help='Add name in thumbinal')
    opt, arguments = parser.parse_args(args=arg,)
    try:
        name = arguments[0]
    except IndexError:
        parser.print_help()
        print "No parametrs. "
        exit()
    return opt, arguments

def ipicture(file_name):
    ihost,form_vaule=imagehost.ipicture(label(file_name))
    #
    reurl=libiu.send_file(file_name[0], ihost, form_vaule)
    reurl=reurl.getheaders()[-5]
    reurl=re.findall('(http://.*.html)',reurl[1])
    url=re.findall('\[IMG\](http://.*)\[\/IMG\]',urllib.urlopen(reurl[0]).read())
    url=[url[0],url[2]]
    return url
def radikal(file_name):
    ihost,form_vaule=imagehost.radikal(label(file_name))
    url=libiu.send_file(file_name[0], ihost, form_vaule)
    url=re.findall('\[IMG\](http://.*.radikal.ru.*)\[/IMG\]',url.read())
    return url
def funkyimg(file_name):
    ihost,form_vaule=imagehost.funkyimg(label(file_name))
    url=re.findall('\[IMG\](http://funkyimg.com/.*)\[/IMG\]\[/URL\]',\
                     libiu.send_file(file_name[0], ihost, form_vaule).read())
    url.reverse()
    return url

def output(url):
        tmpurl1='%s%s\n' %(tmpurl1,url[0])
        tmpurl2='%s[URL=%s][IMG]%s[/IMG][/URL] ' % (tmpurl2, url[0], url[1])
        tmpurl3='%s[IMG]%s[/IMG]\n' % (tmpurl3,url[0])
        tmpurl4='%s[[%s|{{%s}}]]\n' % (tmpurl4,url[0],url[1])
        url['url1']=''
def main(arg):
    opt, filenames=parseopt(arg)
    tmpurl1 = tmpurl2 = tmpurl3 = tmpurl4 = ''
    host=opt.check
    #a=len(arguments)
    for filename in filenames:
        send=[filename,opt.name]
        if host == 'i':
            #url=ipicture(send)
            url=imagehost.ipicture(send)
        if host == 'r':
            url=imagehost.radikal(send)
        if host == 'f':
            url=funkyimg(send)
        if host == 's':
            url=imagehost.imageshack(send)
        if host == 't':
            url=imagehost.tinypic(send)
        tmpurl1='%s%s\n' %(tmpurl1,url[0])
        tmpurl2='%s[URL=%s][IMG]%s[/IMG][/URL] ' % (tmpurl2, url[0], url[1])
        tmpurl3='%s[IMG]%s[/IMG]\n' % (tmpurl3,url[0])
        tmpurl4=''#'%s[[%s|{{%s}}]]\n' % (tmpurl4,url[0],url[1])
    print '%s\n%s\n\n%s\n%s'%(tmpurl1,tmpurl2,tmpurl3,tmpurl4)

#main(sys.argv[1:])
main(argv[1:])



