#!/usr/bin/python
# -*- coding: utf-8 -*-
import optparse
from sys import argv,exit
import imagehost
'''
apkawa@gmail.com
Добавлены 2 хостинга, imageshack.us и tinypic.com. Проведен небольшой рефакторинг кода.
'''


def parseopt(arg):
    usage = "usage: %prog [options] picture."
    parser = optparse.OptionParser(usage=usage)
    parser.add_option('-i','--ipicture',action='store_const', const='i', dest='check', help='Upload to ipicture.ru')
    parser.add_option('-r','--radikal',action='store_const', const='r', dest='check', help='Upload to radikal.ru')
    parser.add_option('-f','--funkyimg',action='store_const', const='f', dest='check', help='Upload to funkyimg.com')
    parser.add_option('-s','--imageshack',action='store_const', const='s', dest='check', help='Upload to imageshack.us')
    parser.add_option('-t','--tinypic',action='store_const', const='t', dest='check', help='Upload to tinypic.com')
    parser.add_option('-n','--name', action='store', default=None, dest='name', help='Add name in thumbinal (Used PIL)')
    opt, arguments = parser.parse_args(args=arg,)
    try:
        name = arguments[0]
    except IndexError:
        parser.print_help()
        print "No parametrs. "
        exit()
    return opt, arguments

def main(arg):
    opt, filenames=parseopt(arg)
    tmpurl1 = []
    tmpurl2 = []
    tmpurl3 = []
    tmpurl4 = []
    host=opt.check
    #a=len(arguments)
    for filename in filenames:
        send=[filename,opt.name]
        if host == 'i':
            #url=ipicture(send)
            url=imagehost.ipicture(send)
        if host == 'r':
            url=imagehost.radikal(send)
        if host == 'f':
            url=funkyimg(send)
        if host == 's':
            url=imagehost.imageshack(send)
        if host == 't':
            url=imagehost.tinypic(send)
        tmpurl1.append(url[0])
        tmpurl2.append('[URL=%s][IMG]%s[/IMG][/URL] ' % (url[0], url[1]))
        tmpurl3.append('[IMG]%s[/IMG]\n' % (url[0]))
        
    results=[]
    results.extend(tmpurl1)
    results.append('\n')
    results.extend(tmpurl2)
    results.append('\n')
    results.extend(tmpurl3)
    
    print '\n'.join(results)

main(argv[1:])



